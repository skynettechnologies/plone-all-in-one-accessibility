# -*- coding: utf-8 -*-
# from plone.app.textfield import RichText
# from plone.autoform import directives
from plone.dexterity.content import Item

# from plone.namedfile import field as namedfile
from plone.supermodel import model
from plone import api

# from plone.supermodel.directives import fieldset
# from z3c.form.browser.radio import RadioFieldWidget
from zope import schema
from zope.interface import implementer


# from plone.all_in_one_accessibility import _


class IAllInOneAccessibilitySetting(model.Schema):
    aioa_key = schema.TextLine(
        title='License Key',
        required=False,
        readonly=False,
    )
    
    aioa_color = schema.TextLine(
        title='Hex color code',
        description='You can cutomize the ADA Widget color. For example: #FF5733',
        
       
        required=False,
        readonly=False,
    )
    
    aioa_place = schema.Choice(
        title='Where would you like to place the accessibility icon on your site',
        values=['top_left',
      'top_center',
      'top_right',
      'middel_left',
      'middel_right',
      'bottom_left',
      'bottom_center',
      'bottom_right']
    )


@implementer(IAllInOneAccessibilitySetting)
class AllInOneAccessibilitySetting(Item):
    """ Content-type class for IAllInOneAccessibilitySetting
    """
    def __init__(self, id=None, **kwargs):
        catalog = api.portal.get_tool('portal_catalog')
        brains = catalog(portal_type='All in One Accessibility setting')
        if brains:
            raise Exception('Only one "All in One Accessibility setting" object is allowed per Plone instance')

        super(AllInOneAccessibilitySetting, self).__init__(id, **kwargs)
        
from z3c.form.object import registerFactoryAdapter
registerFactoryAdapter(IAllInOneAccessibilitySetting, AllInOneAccessibilitySetting)