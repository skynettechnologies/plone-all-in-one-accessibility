Contributors
============

- FakeGitUserOrEmail, FakeGitUserOrEmail
